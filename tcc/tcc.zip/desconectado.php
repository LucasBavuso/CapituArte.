<html>
    <head></head>
    <body>
        <h1>ACESSO N&Atilde;O AUTORIZADO</h1><br/>
        <form action='logar.php'>
            <input type=submit value="VAI PARA LOGIN"/>
        </form>
        
    </body>
    </html>